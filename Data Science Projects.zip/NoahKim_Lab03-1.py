
# coding: utf-8

# In[1]:

#General Jupyter Configuration
import warnings
warnings.filterwarnings('ignore')
get_ipython().magic('matplotlib inline')
import pandas
import statsmodels.formula.api
import random
import scipy.optimize
import numpy as np
import math
import pylab
import collections
import matplotlib.pyplot as plt
import sklearn.tree 
import sklearn.model_selection
import sklearn.metrics
import time
import os
import os.path
import multiprocessing

#steps
#1. change model
#2. pick your own preferences
#3. you will add uncertainty based on your preferences
#4. incorp. parralelization, which runs multiple models at once, making it more efficient 


# In[2]:

import pandas
allKSdata = pandas.read_csv("./ks-projects-201801.csv")
print(allKSdata.head())


# In[ ]:

##=======================================##
##=======================================##
#Lab 3 Part 2.5: Putting it all together - Parallel Simulation of Human Uncertainty
##=======================================##
##=======================================##



#Re-import my Data and Modules so I can run this snippet on it's own:
import warnings
warnings.filterwarnings('ignore')
get_ipython().magic('matplotlib inline')

import pandas
import statsmodels.formula.api
import random
import scipy.optimize
import numpy as np
import math
import pylab
import collections
import matplotlib.pyplot as plt
import sklearn.tree 
import sklearn.model_selection
import sklearn.metrics
import time
import os
import os.path

#new module!
import multiprocessing


#===AHP Function Definition======#
#I'm going to define a function that helps us calculate the AHP
def AHP(decision_matrix):
        
    #Random Consistency Index (RI)
    RI = [0, 0, 0.58, 0.90, 1.12, 1.24, 1.32, 1.41, 1.45, 1.49, 
          1.51, 1.48, 1.56, 1.57, 1.59]

    #Read data
    #data = np.fromfile('data.tsv', dtype=np.float128, sep=" "); n=int(len(data)**(0.5))
    #???????????????????????WHY IS ^ HIDDEN?????????????????????????????????
    A = decision_matrix
    n = len(A)    
    
    # Complete inferior part with inverse values 1/x
    for a in range(len(A)):
        for b in range(len(A)):
            if a > b:
                A[a][b] = 1./A[b][a]
    A[A > 1] = np.round(A[A > 1]); A[A < 1] = np.round(A[A < 1], 3) # Round values
    # Normalize matrix
    A = A**1

    # Eigenvalue
    alpha = A.sum(axis=1)
    w = alpha/A.sum()

    # Consistency ratio calculation
    CI = (np.amax(alpha)-n)/(n-1)
    CR = CI/RI[n-1]
    return(w.round(4))

#Load the data 
allKSdata = pandas.read_csv("./ks-projects-201801.csv")

#Drop Kickstarter categories that do not have at least 25,000 projects in the record.
bigCategoriesOnly = allKSdata[allKSdata.main_category != 'Comics']
bigCategoriesOnly = bigCategoriesOnly[bigCategoriesOnly.main_category != 'Crafts']
bigCategoriesOnly = bigCategoriesOnly[bigCategoriesOnly.main_category != 'Dance']
bigCategoriesOnly = bigCategoriesOnly[bigCategoriesOnly.main_category != 'Fashion']
bigCategoriesOnly = bigCategoriesOnly[bigCategoriesOnly.main_category != 'Food']
bigCategoriesOnly = bigCategoriesOnly[bigCategoriesOnly.main_category != 'Journalism']
bigCategoriesOnly = bigCategoriesOnly[bigCategoriesOnly.main_category != 'Photography']
bigCategoriesOnly = bigCategoriesOnly[bigCategoriesOnly.main_category != 'Theater']
#The only Kickstarter categories remaining that I want to use are the following:
#I need the ID of the Kickstarter to join information
#Counrtry and Goals are the only features that I use to determine (use normalized goal) usd_goal_real
#Use Main Category to add in my personal ADDED GOAL
#maybe use year when it was launched because 
bigCategoriesOnly = bigCategoriesOnly[['ID','country', 'usd_goal_real', 'goal', 'state', 'main_category', 'pledged']] 
#, 'backers' 'goal'

#Build my model (no uncertainty at this stage):
#I map each country initial to a number 
bigCategoriesOnly['country'] = bigCategoriesOnly['country'].replace({'GB': 1,'US': 2, 'CA': 3, 
                                                                     'AU': 4, 'NO': 5, 'IT': 6, 'DE': 7, 
                                                                     'IE': 8, 'MX': 9, 'ES': 10, 'N,0"':11, 
                                                                     'SE': 12, 'FR': 13, 'NL': 14, 'NZ': 15, 
                                                                     'CH': 16, 'AT': 17, 'DK': 18, 'BE': 19, 
                                                                     'HK': 20, 'LU': 21, 'SG': 22, 'JP': 23 })

#I want to focus just on whether a kickstarter project was successful or not
#Keeping the classification binary (success and not success) allows the classification tree to run more efficiently
#and accurately
projectSuccess = bigCategoriesOnly['state'].map({'successful': 1, 'failed': 0, 
                                                 'canceled': 0, 'live': 0, 
                                                 'undefined': 0, 'suspended': 0
                                        })

#ADD MORE VARIABLES!!!!!

#I define the variables we want to use in prediction
#I drop the state, main category, and ID because I do not use these variables to predict the success
#of a kickstartes, leaving country and goal
predicting_variables = bigCategoriesOnly.drop(['state','main_category','ID'], axis=1)

#Because I have so much data, I can seperate it into two different parts -
#A "training" set I use to make my model, and then a "test" set I test our model on.
#I do this all at once with one line of code, creating sets of variables for both my
#Kickstarter Success variable and all of my predicting variables:
#Note the "random state" here is just to ensure that I get the same results every time 
#(i.e., the same two sets of data are created).
predicting_train, predicting_test, success_train, success_test = sklearn.model_selection.train_test_split(predicting_variables, projectSuccess, random_state=1697)

#I'm going to fit a simulation tree
#SET MAX DEPTH TO YOUR OWN LIKING!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! changed it to 7
classification_tree = sklearn.tree.DecisionTreeClassifier(max_depth=6).fit(predicting_train,success_train)

#I can test my model's accuracy
print("The % of estimates I get right with a depth of 6 is:")
predictions = classification_tree.predict(predicting_test)
print(sklearn.metrics.accuracy_score(success_test, predictions))

#Add my predicted probabilities for success in to the original Dataframe:
select_KS = bigCategoriesOnly.copy(deep=True)
select_KS["predicted_success"] = classification_tree.predict_proba(predicting_variables)[:,1]

#Now, commence the uncertainty!
#First, I'm going to define a function.
#Remember, this code is not run until later on.
#What we're going to do is tell lots of computers all to do the same thing at once.

#we tell Jupyter to use all the cores at once for each to run an iteration
def KS_project_picker(KS_data,top_n,filename):
    
    #I build a decision matrix that specifies my preferences
    #I'm going to add some uncertainty into my decision matrix each time.
    #I based these uncertainties on my own personal unknowns.
    
    #randomness should be included when you are uncertain of the choice, the range is very important 
    #we add randomness to our iterations
    #we set at 100,000 iterations to capture all of the true potential human preferences 
    #helps account for my own uncertainty in my choices; normal for any human to do. 
    
    dm = np.array([
        [1.0+random.random(),1.0,0.5,0.25,0.5,0.5,0.25],
        [0.0,1.0,1.0-random.random(),0.25,1.0,0.5,0.5+random.random()],
        [0.0,0.0,1.0,1.0,1.0,1.0,0.5+random.random()],
        [0.0,0.0,0.0,1.0,2.0,1.0,0.75-random.random()],
        [0.0,0.0,0.0+random.uniform(1,8),0.0,1.0,2.0,0.5],
        [0.0,0.0,0.0,0.0,0.0,1.0+random.uniform(1,8),0.25],    
        #(1,8) is the uncertainity of my own brain, meaning that it could also be from 0 to 8 in 
        #importance it is adding to already present preference 
        [0.0,0.0,0.0,0.0,0.0,0.0,1.0]
    ])

    #I put these random.random and random.uniform for uncertainity because it reflected my unpredictability; I often
    #have varying moods and changes depending on the setting, so I believed that my final results would have a greater 
    #selection of titles because that more greatly reflects what would actually happen. 

      #add uncertainty to AHP
    #Now, I'm going to calculate the weights for each category 
    AHP_weights = AHP(dm)
    KS_data['main_category'] = KS_data['main_category'].replace({
                                         'Art': AHP_weights[0], 
                                         'Design': AHP_weights[1],
                                         'Film & Video': AHP_weights[2],
                                         'Games': AHP_weights[3],
                                         'Music': AHP_weights[4],
                                         'Publishing': AHP_weights[5], 
                                         'Technology': AHP_weights[6],
                                        })
    
    KS_data['Overall_Score'] = KS_data['main_category'] * KS_data['predicted_success']

    top = KS_data.nlargest(top_n, 'Overall_Score') #WHERE IS TOP N DEFINED??
    
    #Have every core write a unique file
    #(we're cheating a little by using random.random for the file name)
    #..but it's pretty safe for the small-scale work we're doing here.
    #This code allows me to save the data, even if Jupyter expires
    write_out = open("./my_simulation_results/"+filename+"_"+str(random.random())+".csv",mode='w')
    for i in allKSdata.loc[allKSdata["ID"].isin(top["ID"].values)].name.values:
        write_out.write(i + ",")
    write_out.close()
    return(allKSdata.loc[allKSdata["ID"].isin(top["ID"].values)].name.values)

#You can run this once to see what an output looks like - each time your run it, you will likely
#see a different project.:
#KS_project_picker(KS_data = select_KS.copy(deep=True), top_n = 2, filename = "KS_projects")

########################WHY IS ^ HIDDEN????????????????????????????????????????????????????

#I initialy wanted removed STATE. MNETION IN LIMITATIONS B/C I wanted to be considered a category for prediction and not dropped. main category and ID can be kept
#because it doesn't help determine the success of the kickstarter. However, I believe that state vital variable in the 
#prediction process. DIDN'T WANT TO BECAUSE NOT TIME EFFECTIVE, HAD TO MANUALLY HAD 50 SATES UNDER projectSuccess, this time c
#consuming action would not work in highly corporation. 



#Now, we're going to do it a thousand times, using all of the cores at our disposal:
#First, define all of our jobs.  Conveniently, they're the same for us.
#do 100,000 iterations
#2 is to return the top 2 dams 
iterations = 100000
setup_processors = [select_KS.copy(deep=True), 2, "KS_projects"]
jobs = [multiprocessing.Process(target = KS_project_picker, args=setup_processors) for x in range(iterations)]

for job in jobs:
    job.start()    


# In[8]:

import glob
import os   
import pandas

#If you look in your folder, you'll see a CSV file for every iteration.  
#Every time you run the code, you'll get <iteration> more files.
#It's highly, highly recommended you edit line 144 in the above snippet
#and create a new folder for each time you run the code.

#Now that I have all of my iterations, I need to put the results together.
#To do that, I need to loop through each CSV I just generated, and concatenate the results.

#Doing it this way means that even if my Jupyter turns off, I can still pick up where I left off.
all_files = glob.glob(os.path.join('./simulation_results/', "*.csv")) 
#print(all_files)
df_set = (pandas.read_csv(f, header=None) for f in all_files)
all_simulation_results = pandas.concat(df_set, ignore_index=True)

#Now, let's create our bar chart telling us how many times each one was picked.
flat_list = [item for sublist in all_simulation_results.values for item in sublist]
noNAList = [x for x in flat_list if str(x) != 'nan']
KS_counts = collections.Counter(noNAList)
plt.bar(range(len(KS_counts)), list(KS_counts.values()), align='center')
plt.xticks(range(len(KS_counts)), list(KS_counts.keys()), rotation="vertical")
plt.ylabel("Number of Iterations KS in Top 2")
plt.xlabel("KS Name")
plt.title("KS in Top 2")
plt.show()


# In[ ]:




# In[ ]:



